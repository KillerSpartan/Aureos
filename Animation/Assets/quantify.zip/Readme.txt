Hello!

Thanks for download and use our font.

Quantify free for personal use.

For commercial use and to get the font license

please contact me: 

saidi.uchiha@yahoo.com

---------------------

Designed by Saidi Alfianor
Copyright (c) 2018 by Sentype Foundry. All rights reserved.